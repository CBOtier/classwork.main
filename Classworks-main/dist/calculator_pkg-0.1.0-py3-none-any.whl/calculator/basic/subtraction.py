# subtraction.py
def subtract(a, b):
    return a - b