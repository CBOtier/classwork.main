# multiplication.py
def multiply(a, b):
    return a * b