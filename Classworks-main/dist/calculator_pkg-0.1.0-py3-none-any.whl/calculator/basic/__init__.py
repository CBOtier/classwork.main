# __init__.py in basic
from .addition import add
from .subtraction import subtract
from .multiplication import multiply