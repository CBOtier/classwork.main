import math
def cos(x):
    return math.cos(x)
