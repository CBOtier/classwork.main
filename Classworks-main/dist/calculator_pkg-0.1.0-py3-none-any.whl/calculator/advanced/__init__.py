# __init__.py in advanced
from .exponentiation import power
from .root import square_root